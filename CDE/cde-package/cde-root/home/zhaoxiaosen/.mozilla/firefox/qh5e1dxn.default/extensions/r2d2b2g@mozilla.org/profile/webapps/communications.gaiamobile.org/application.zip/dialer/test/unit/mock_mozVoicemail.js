'use strict';

var MockMozVoicemail = {
  number: null
};
