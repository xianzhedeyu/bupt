var MockConfirmDialog = {
  show: function() {},
  hide: function() {}
};
