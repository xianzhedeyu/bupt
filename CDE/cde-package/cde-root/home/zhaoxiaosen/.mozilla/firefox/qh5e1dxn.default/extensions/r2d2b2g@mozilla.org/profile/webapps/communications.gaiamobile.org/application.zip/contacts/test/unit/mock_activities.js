'use strict';

var MockActivities = {
  currentlyHandling: false
};
