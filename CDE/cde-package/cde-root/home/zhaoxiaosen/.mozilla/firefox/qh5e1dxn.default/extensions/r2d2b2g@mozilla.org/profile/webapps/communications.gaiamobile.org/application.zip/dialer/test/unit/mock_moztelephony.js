var MockMozTelephony = {
  dial: function() {},
  active: null,
  calls: null
};

